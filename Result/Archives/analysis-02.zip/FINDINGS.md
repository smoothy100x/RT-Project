# Runtime findings

NoAuction_Zscore, h=30: validation-selected full144/ols, heldout macro-F1 0.3630; training-majority 0.2235; difference +0.1395. This is a descriptive heldout comparison.

NoAuction_Zscore, h=10: validation-selected full144/wls, heldout macro-F1 0.2857; training-majority 0.2671; difference +0.0186. This is a descriptive heldout comparison.

NoAuction_Zscore, h=20: validation-selected full144/wls, heldout macro-F1 0.3684; training-majority 0.2418; difference +0.1266. This is a descriptive heldout comparison.

NoAuction_Zscore, h=100: validation-selected basis/ols, heldout macro-F1 0.4406; training-majority 0.1851; difference +0.2555. This is a descriptive heldout comparison.

NoAuction_Zscore, h=50: validation-selected basis/wls, heldout macro-F1 0.4117; training-majority 0.1921; difference +0.2197. This is a descriptive heldout comparison.

Auction_DecPre, h=10: validation-selected full144/ols, heldout macro-F1 0.2844; training-majority 0.2788; difference +0.0056. This is a descriptive heldout comparison.

Auction_DecPre, h=20: validation-selected full144/ols, heldout macro-F1 0.3678; training-majority 0.2533; difference +0.1144. This is a descriptive heldout comparison.

Auction_DecPre, h=30: validation-selected full144/ols, heldout macro-F1 0.3559; training-majority 0.2322; difference +0.1237. This is a descriptive heldout comparison.

Auction_DecPre, h=100: validation-selected basis/ols, heldout macro-F1 0.4277; training-majority 0.1814; difference +0.2463. This is a descriptive heldout comparison.

Auction_DecPre, h=50: validation-selected basis/wls, heldout macro-F1 0.4066; training-majority 0.1998; difference +0.2068. This is a descriptive heldout comparison.

Auction_MinMax, h=10: validation-selected full144/ols, heldout macro-F1 0.2850; training-majority 0.2788; difference +0.0062. This is a descriptive heldout comparison.

Auction_MinMax, h=20: validation-selected full144/ols, heldout macro-F1 0.3660; training-majority 0.2533; difference +0.1127. This is a descriptive heldout comparison.

Auction_MinMax, h=30: validation-selected full144/ols, heldout macro-F1 0.3558; training-majority 0.2322; difference +0.1236. This is a descriptive heldout comparison.

Auction_MinMax, h=100: validation-selected basis/ols, heldout macro-F1 0.4277; training-majority 0.1814; difference +0.2463. This is a descriptive heldout comparison.

Auction_MinMax, h=50: validation-selected basis/wls, heldout macro-F1 0.4066; training-majority 0.1998; difference +0.2068. This is a descriptive heldout comparison.

Auction_Zscore, h=10: validation-selected full144/wls, heldout macro-F1 0.2849; training-majority 0.2788; difference +0.0061. This is a descriptive heldout comparison.

Auction_Zscore, h=20: validation-selected full144/wls, heldout macro-F1 0.3694; training-majority 0.2533; difference +0.1161. This is a descriptive heldout comparison.

Auction_Zscore, h=30: validation-selected full144/wls, heldout macro-F1 0.3574; training-majority 0.2322; difference +0.1252. This is a descriptive heldout comparison.

Auction_Zscore, h=100: validation-selected basis/ols, heldout macro-F1 0.4277; training-majority 0.1814; difference +0.2463. This is a descriptive heldout comparison.

Auction_Zscore, h=50: validation-selected basis/wls, heldout macro-F1 0.4066; training-majority 0.1998; difference +0.2068. This is a descriptive heldout comparison.

NoAuction_DecPre, h=10: validation-selected full144/wls, heldout macro-F1 0.2853; training-majority 0.2671; difference +0.0183. This is a descriptive heldout comparison.

NoAuction_DecPre, h=20: validation-selected full144/wls, heldout macro-F1 0.3686; training-majority 0.2418; difference +0.1268. This is a descriptive heldout comparison.

NoAuction_DecPre, h=30: validation-selected full144/wls, heldout macro-F1 0.3641; training-majority 0.2235; difference +0.1405. This is a descriptive heldout comparison.

NoAuction_DecPre, h=100: validation-selected basis/ols, heldout macro-F1 0.4406; training-majority 0.1851; difference +0.2555. This is a descriptive heldout comparison.

NoAuction_DecPre, h=50: validation-selected basis/wls, heldout macro-F1 0.4117; training-majority 0.1921; difference +0.2197. This is a descriptive heldout comparison.

NoAuction_MinMax, h=10: validation-selected full144/wls, heldout macro-F1 0.2849; training-majority 0.2671; difference +0.0178. This is a descriptive heldout comparison.

NoAuction_MinMax, h=20: validation-selected full144/wls, heldout macro-F1 0.3690; training-majority 0.2418; difference +0.1271. This is a descriptive heldout comparison.

NoAuction_MinMax, h=30: validation-selected full144/wls, heldout macro-F1 0.3637; training-majority 0.2235; difference +0.1401. This is a descriptive heldout comparison.

NoAuction_MinMax, h=100: validation-selected basis/ols, heldout macro-F1 0.4406; training-majority 0.1851; difference +0.2555. This is a descriptive heldout comparison.

NoAuction_MinMax, h=50: validation-selected basis/wls, heldout macro-F1 0.4117; training-majority 0.1921; difference +0.2197. This is a descriptive heldout comparison.

All t/F p-values and confidence intervals are Gaussian IID reference quantities only. Discrete labels violate normality; overlapping horizons and adjacent books violate independence.

Direction score is an ordinal coding, not a continuous return. Indicator regressions are linear probability models: scores may lie outside [0,1] and are not calibrated probabilities.

No stock IDs or reliable within-day stock boundaries are supplied in the benchmark matrices. No synthetic lagged features, monetary backtest, spread reconstruction, or trade-level interpretation is attempted.

Upstream benchmark normalization fitting scope is not verified. Additional scaling, rank selection, basis selection and variance fitting use training rows only.

All fold copies and normalization copies describe overlapping observations. They are never pooled as independent samples.

Block deletion is a sensitivity study, not a bootstrap confidence interval. Nominal significance is not proof of an edge.